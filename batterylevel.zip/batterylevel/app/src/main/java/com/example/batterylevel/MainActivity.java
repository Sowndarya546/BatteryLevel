package com.example.batterylevel;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TextView t;
    public int level;
    int deviceStatus;
    String currentBatteryStatus = "Battery Info";
    int batteryLevel;
    int scale;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        t=findViewById(R.id.txt);
        this.registerReceiver(broadcastreceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));

    }

    public BroadcastReceiver broadcastreceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            deviceStatus = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            batteryLevel = (int) (((float) level / (float) scale) * 100.0f);

            if (deviceStatus == BatteryManager.BATTERY_STATUS_CHARGING) {

                t.setText(currentBatteryStatus + " = Charging at " + batteryLevel + " %");

            }

            if (deviceStatus == BatteryManager.BATTERY_STATUS_DISCHARGING) {

                t.setText(currentBatteryStatus + " = Discharging at " + batteryLevel + " %");

            }

            if (deviceStatus == BatteryManager.BATTERY_STATUS_FULL) {

                t.setText(currentBatteryStatus + "= Battery Full at " + batteryLevel + " %");

            }

            if (deviceStatus == BatteryManager.BATTERY_STATUS_UNKNOWN) {

                t.setText(currentBatteryStatus + " = Unknown at " + batteryLevel + " %");
            }


            if (deviceStatus == BatteryManager.BATTERY_STATUS_NOT_CHARGING) {

                t.setText(currentBatteryStatus + " = Not Charging at " + batteryLevel + " %");

            }
            if (batteryLevel <= 20) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    CharSequence name = MainActivity.this.getString(R.string.app_name);
                    String description = MainActivity.this.getString(R.string.app_name);
                    int importance = NotificationManager.IMPORTANCE_DEFAULT;
                    NotificationChannel channel = new NotificationChannel(MainActivity.this.getString(R.string.app_name), name, importance);
                    channel.setDescription(description);
                    // Register the channel with the system; you can't change the importance
                    // or other notification behaviors after this
                    NotificationManager notificationManager = MainActivity.this.getSystemService(NotificationManager.class);
                    notificationManager.createNotificationChannel(channel);
                }

                NotificationCompat.Builder builder = new NotificationCompat.Builder(MainActivity.this, MainActivity.this.getString(R.string.app_name))
                        .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                        .setContentTitle("Battery Percentage")
                        .setContentText("Your batterylevel is " + batteryLevel + "are u safe..then please charge your mobile")
                        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                        .setStyle(new NotificationCompat.BigTextStyle().bigText("Your batterylevel is " + batteryLevel + "are u safe..then please charge your mobile"));

                NotificationManagerCompat notificationManager = NotificationManagerCompat.from(MainActivity.this);

                // notificationId is a unique int for each notification that you must define
                notificationManager.notify(1001, builder.build());
                Toast.makeText(MainActivity.this, "Low Battery", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity.this, "High Battery", Toast.LENGTH_SHORT).show();
            }


        }
    };



}
